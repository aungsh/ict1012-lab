#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

// ICT1012 Lab 4 ----------------
#include "fcntl.h"      // For PROT_READ, PROT_WRITE
#include "sleeplock.h"  // Required by file.h
#include "fs.h"         // Required by file.h
#include "file.h"
//-------------------------------

struct spinlock tickslock;
uint ticks;

extern char trampoline[], uservec[];

// in kernelvec.S, calls kerneltrap().
void kernelvec();

extern int devintr();

void
trapinit(void)
{
  initlock(&tickslock, "time");
}

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
  w_stvec((uint64)kernelvec);
}


// ICT1012 Lab 4 ----------------
int mmap_handler(uint64 va, struct vma *v) {
  struct proc *p = myproc();
  uint64 va_aligned = PGROUNDDOWN(va);
  
  // 1. allocate a Physical Page
  char *mem = kalloc();
  if(mem == 0) return -1;
  memset(mem, 0, PGSIZE);

  // 2. calculate the offset
  uint offset = va_aligned - v->addr;

  // 3. read file data from disk
  // use ilock/readi to read the data to the mem page allocated
  begin_op();
  ilock(v->f->ip);
  readi(v->f->ip, 0, (uint64)mem, offset, PGSIZE);
  iunlock(v->f->ip);
  end_op();

  // 4. set up the permission bits
  int perm = PTE_U;
  if(v->prot & PROT_READ)  perm |= PTE_R;
  if(v->prot & PROT_WRITE) perm |= PTE_W;

  // 5. map the virtual page to the physical page
  if(mappages(p->pagetable, va_aligned, PGSIZE, (uint64)mem, perm) != 0) {
    kfree(mem);
    return -1;
  }

  return 0;
}

//-------------------------------



//
// handle an interrupt, exception, or system call from user space.
// called from, and returns to, trampoline.S
// return value is user satp for trampoline.S to switch to.
//
uint64
usertrap(void)
{
  int which_dev = 0;

  if((r_sstatus() & SSTATUS_SPP) != 0)
    panic("usertrap: not from user mode");

  // send interrupts and exceptions to kerneltrap(),
  // since we're now in the kernel.
  w_stvec((uint64)kernelvec);  //DOC: kernelvec

  struct proc *p = myproc();
  
  // save user program counter.
  p->trapframe->epc = r_sepc();
  
  if(r_scause() == 8){
    // system call

    if(killed(p))
      kexit(-1);

    // sepc points to the ecall instruction,
    // but we want to return to the next instruction.
    p->trapframe->epc += 4;

    // an interrupt will change sepc, scause, and sstatus,
    // so enable only now that we're done with those registers.
    intr_on();

    syscall();
  } else if((which_dev = devintr()) != 0){
      // ok
  } else if((r_scause() == 15 || r_scause() == 13)) {      
      // ICT1012 Lab 4 ----------------
      // get the virtual address causing the page fault
      uint64 va = r_stval();

      // 1. Check if this virtual address is within a valid VMA
      struct vma *v = 0;

      for(int i = 0; i < MAX_VMA; i++){
        if(p->vmas[i].valid == 0)
          continue;
        uint64 start = p->vmas[i].addr;
        uint64 end = p->vmas[i].addr + p->vmas[i].length;
        if(va >= start && va < end){
          v = &p->vmas[i];
          break;
        }
      }

      
      
      
      
      if(v != 0) {    
        // the virtual address is within a valid VMA
        // Handle VMA fault
        // Check protection and flags
        // call mmap_handler, which is implemented above

        if(r_scause() == 15 && ((v->prot & PROT_WRITE) == 0)){
          setkilled(p);
        } else {
          if(mmap_handler(va, v) != 0){
            setkilled(p);
          }
        }

















      } else {    
          // 2. Not a VMA: Check if it's a valid Lazy Heap (sbrk) fault
          // Addresses must be below p->sz and above the stack
          // Handle Heap fault (Lazy SBRK)
          // Now that VMAs are at 0x40000000, unmapped VMA addresses will NOT be < p->sz.
          // FIX for munmap_noaccess: Only allow lazy allocation for the heap
          if(va < p->sz && va >= p->trapframe->sp) {

            if(vmfault(p->pagetable, va, 0) == 0){
              setkilled(p);
            }



            
            //-------------------------------        
          } else {
            // 3. Invalid access (including unmapped MMAP memory): Kill process
            // If it's not a VMA and not in the heap, kill the process.
            // page fault on lazily-allocated page
            //printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
            //printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
            setkilled(p);
          }
      }
  } else {
      // Other traps...
      setkilled(p);
  }

  if(killed(p))
    kexit(-1);

  // give up the CPU if this is a timer interrupt.
  if(which_dev == 2)
    yield();

  usertrapret();

  // the user page table to switch to, for trampoline.S
  uint64 satp = MAKE_SATP(p->pagetable);

  // return to trampoline.S; satp value in a0.
  return satp;
}

//
// set up trapframe and control registers for a return to user space
//
void
usertrapret(void)
{
  struct proc *p = myproc();

  // we're about to switch the destination of traps from
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
  p->trapframe->kernel_trap = (uint64)usertrap;
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()

  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
  x |= SSTATUS_SPIE; // enable interrupts in user mode
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
}

// interrupts and exceptions from kernel code go here via kernelvec,
// on whatever the current kernel stack is.
void 
kerneltrap()
{
  int which_dev = 0;
  uint64 sepc = r_sepc();
  uint64 sstatus = r_sstatus();
  uint64 scause = r_scause();
  
  if((sstatus & SSTATUS_SPP) == 0)
    panic("kerneltrap: not from supervisor mode");
  if(intr_get() != 0)
    panic("kerneltrap: interrupts enabled");

  if(scause == 0xd) {
    printf("load page fault!\n");
  }
  if(scause == 0xf) {
    printf("store page fault!\n");
  }

  if((which_dev = devintr()) == 0){
    // interrupt or trap from an unknown source
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    panic("kerneltrap");
  }

  // give up the CPU if this is a timer interrupt.
  if(which_dev == 2 && myproc() != 0)
    yield();

  // the yield() may have caused some traps to occur,
  // so restore trap registers for use by kernelvec.S's sepc instruction.
  w_sepc(sepc);
  w_sstatus(sstatus);
}

void
clockintr()
{
  if(cpuid() == 0){
    acquire(&tickslock);
    ticks++;
    wakeup(&ticks);
    release(&tickslock);
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
}

// check if it's an external interrupt or software interrupt,
// and handle it.
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    // this is a supervisor external interrupt, via PLIC.

    // irq indicates which device interrupted.
    int irq = plic_claim();

    if(irq == UART0_IRQ){
      uartintr();
    } else if(irq == VIRTIO0_IRQ){
      virtio_disk_intr();
    } else if(irq){
      printf("unexpected interrupt irq=%d\n", irq);
    }

    // the PLIC allows each device to raise at most one
    // interrupt at a time; tell the PLIC the device is
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
  }
}
