echo "hello world!"
ls
